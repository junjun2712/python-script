**1. 简介**

Kubernetes v1.13版本发布后，kubeadm才正式进入GA，可以生产使用,用kubeadm部署kubernetes集群也是以后的发展趋势。目前Kubernetes的对应镜像仓库，在国内阿里云也有了镜像站点，使用kubeadm部署Kubernetes集群变得简单并且容易了很多，本文使用kubeadm带领大家快速部署Kubernetes v1.14.6版本。

**2. 架构信息**


系统版本：CentOS 7.6 内核：3.10.0-957.el7.x86_64 Kubernetes: v1.14.6  Docker-ce: 18.06 
推荐硬件配置：master: 4核4G Keepalived保证apiserever服务器的IP高可用 Haproxy实现apiserver的负载均衡
              node: 12核32G

vip  172.18.14.95

test-paas-k8s-master-0 172.18.14.100

test-paas-k8s-master-1 172.18.14.99

test-paas-k8s-master-2 172.18.14.98

test-paas-k8s-node-0 172.18.14.97

test-paas-k8s-node-1 172.18.14.96


**3.部署前准备工作**
在第台mastet节点和node节点分别执行下面的脚本

sh init.sh


在master01创建ssh密钥

ssh-keygen -t rsa


分发master01的公钥，用于免密登录其他服务器

for n in seq -w 01 06;do ssh-copy-id master-$n;done

**4.部署配置keepalived和haproxy**

master节点安装 

yum install -y keepalived haproxy

keepalived配置改相应的ip参数
/etc/keepalived/keepalived.conf

haproxy配置改相应的ip参数
/etc/haproxy/haproxy.conf

**5.初始化maste01**


kubeadm init --config kubeadm-init.yaml

部署flannel
kubectl apply -f https://raw.githubusercontent.com/coreos/flannel/master/Documentation/kube-flannel.yml

分发kubernetes证书（master节点需要）

sh scp.sh

以上只要在master 第一个节点上执行

==============================================================================================================

初始化完成会生下面的参数（注：每次都不一样）

这个是master节点加入参数
kubeadm join 172.18.14.95:8443 --token rnupok.yccqtowpdjbi8dcs \
  --discovery-token-ca-cert-hash sha256:720512cb5c65060436a3bef29bdb2d866ae8ae4439fda3bf44b4b6bcfa6f8034 \
  --experimental-control-plane          


这个是node节点加入参数
kubeadm join 172.18.14.95:8443 --token rnupok.yccqtowpdjbi8dcs \
    --discovery-token-ca-cert-hash sha256:720512cb5c65060436a3bef29bdb2d866ae8ae4439fda3bf44b4b6bcfa6f8034 






