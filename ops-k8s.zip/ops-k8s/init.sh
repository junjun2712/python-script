#!/bin/bash

echo -e "\033[31;40m#################Set ipvs##################\033[0m" 

modprobe -- ip_vs

modprobe -- ip_vs_rr

modprobe -- ip_vs_wrr

modprobe -- ip_vs_sh

modprobe -- nf_conntrack_ipv4

echo -e "\033[31;40m#################Set Hosts#################\033[0m" 

cat <<EOF > /etc/hosts

127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4
::1         localhost localhost.localdomain localhost6 localhost6.localdomain6
172.18.14.100  test-paas-k8s-master-0
172.18.14.99   test-paas-k8s-master-1
172.18.14.98   test-paas-k8s-master-2
172.18.14.97   test-paas-k8s-node-0
172.18.14.96   test-paas-k8s-node-1

EOF



echo -e "\033[31;40m#################Shutoff Selinux、firewall、Swap##################\033[0m" 

sed -i "s/^SELINUX=enforcing/SELINUX=disabled/g" /etc/selinux/config

swapoff -a

sed -i 's/.*swap.*/#&/' /etc/fstab

systemctl stop firewalld && systemctl disable firewalld


echo -e "\033[31;40m#################Set yum repo##################\033[0m" 

curl -o /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-7.repo

yum makecache


echo -e "\033[31;40m#################Set kubernetes yum repo##################\033[0m" 

cat <<EOF > /etc/yum.repos.d/kubernetes.repo
[kubernetes]
name=Kubernetes
baseurl=https://packages.cloud.google.com/yum/repos/kubernetes-el7-x86_64
enabled=1
gpgcheck=1
repo_gpgcheck=1
gpgkey=https://packages.cloud.google.com/yum/doc/yum-key.gpg https://packages.cloud.google.com/yum/doc/rpm-package-key.gpg
EOF


echo -e "\033[31;40m#################Set bridge##################\033[0m" 

cat <<EOF > /etc/sysctl.d/k8s.conf

net.bridge.bridge-nf-call-ip6tables = 1

net.bridge.bridge-nf-call-iptables = 1

EOF

sysctl --system


###########################Set kenreal########################

echo "* soft nofile 65536" >> /etc/security/limits.conf

echo "* hard nofile 65536" >> /etc/security/limits.conf

echo "* soft nproc 65536" >> /etc/security/limits.conf

echo "* hard nproc 65536" >> /etc/security/limits.conf

echo "* soft memlock unlimited" >> /etc/security/limits.conf

echo "* hard memlock unlimited" >> /etc/security/limits.conf


echo -e "\033[31;40m#################Installed Basic Software##################\033[0m" 

yum install -y epel-release yum-utils device-mapper-persistent-data lvm2 net-tools conntrack-tools wget vim ntpdate libseccomp libtool-ltdl >> /dev/null

systemctl enable ntpdate.service

echo '*/30 * * * * /usr/sbin/ntpdate time7.aliyun.com >/dev/null 2>&1' > /tmp/crontab2.tmp

crontab /tmp/crontab2.tmp

systemctl start ntpdate.service




###########################Set docker########################

cd /etc/yum.repos.d/


wget https://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo


yum -y install docker-ce-18.06.3.ce


sed -i "11i ExecStartPost=/usr/sbin/iptables -P FORWARD ACCEPT" /usr/lib/systemd/system/docker.service


systemctl daemon-reload


systemctl start docker


systemctl enable docker



yum install -y kubelet-1.14.6 kubeadm-1.13.7 kubectl-1.14.6 ipvsadm ipset


systemctl enable kubelet 


yum -y install openssl-devel gcc

yum install -y keepalived haproxy