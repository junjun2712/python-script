telegram.ChatAction
===================

.. autoclass:: telegram.ChatAction
    :members:
    :show-inheritance:
