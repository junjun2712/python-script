telegram.InlineQueryResultCachedVideo
=====================================

.. autoclass:: telegram.InlineQueryResultCachedVideo
    :members:
    :show-inheritance:
