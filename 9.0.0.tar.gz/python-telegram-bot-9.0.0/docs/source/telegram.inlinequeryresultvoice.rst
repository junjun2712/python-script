telegram.InlineQueryResultVoice
===============================

.. autoclass:: telegram.InlineQueryResultVoice
    :members:
    :show-inheritance:
