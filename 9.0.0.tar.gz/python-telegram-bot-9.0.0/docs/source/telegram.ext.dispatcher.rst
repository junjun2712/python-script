telegram.ext.Dispatcher
=======================

.. autoclass:: telegram.ext.Dispatcher
    :members:
    :show-inheritance:
