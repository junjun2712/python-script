telegram.UserProfilePhotos
==========================

.. autoclass:: telegram.UserProfilePhotos
    :members:
    :show-inheritance:
